# Métricas (implementadas en MetricsCalculator.kt, con tests en MetricsTest.kt)
- Tiempo transcurrido: fin - inicio (incluye pausas). Tiempo activo: suma de segmentos entre pausas, menos huecos > 30 s sin señal.
- Velocidad media activa = distancia / tiempo activo. Ritmo medio activo = tiempo activo / distancia.
- Filtros: precisión > 25 m descartada; velocidad implícita > 12 m/s descartada (salto GPS).
- Máx/mín: ventanas de >= 5 s; menos de 3 ventanas -> "Sin datos". Mín en movimiento ignora ventanas < 0,5 m/s.
- Ritmo agregado: distancia y tiempo acumulados, nunca media de ritmos.
- Umbrales (25 m, 12 m/s, 30 s, 5 s) son decisiones de diseño sin validar en campo: ajustar tras pruebas reales.
