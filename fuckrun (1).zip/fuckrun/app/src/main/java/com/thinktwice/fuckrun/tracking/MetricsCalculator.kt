package com.thinktwice.fuckrun.tracking
import kotlin.math.*

/** Punto GPS. segment aumenta en cada reanudación: nunca se une distancia entre segmentos. */
data class TrackPoint(val timeMs: Long, val lat: Double, val lon: Double, val accuracyM: Float, val segment: Int)

data class SessionMetrics(
    val distanceM: Double, val elapsedMs: Long, val activeMs: Long,
    val avgSpeedKmh: Double?, val maxSpeedKmh: Double?, val minMovingSpeedKmh: Double?,
    val avgPaceSecPerKm: Double?, val lostGapMs: Long
)

/**
 * Reglas (documentadas en docs/METRICAS.md):
 *  - Descarta puntos con precisión > 25 m.
 *  - Descarta saltos con velocidad implícita > 12 m/s (43 km/h, imposible corriendo).
 *  - Hueco > 30 s dentro de un segmento: tramo NO medido; no suma distancia ni se dibuja unido.
 *  - Tiempo activo = suma de duraciones de segmentos (excluye pausas).
 *  - Máx/mín: ventanas de >= 5 s sobre puntos válidos; con menos de 3 ventanas -> null.
 *  - Mínima en movimiento: solo ventanas con velocidad >= 0,5 m/s.
 */
object MetricsCalculator {
    const val MAX_ACCURACY_M = 25f
    const val MAX_SPEED_MS = 12.0
    const val GAP_MS = 30_000L
    const val WINDOW_MS = 5_000L
    const val MOVING_MS = 0.5

    fun haversineM(a: TrackPoint, b: TrackPoint): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(b.lat - a.lat); val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }

    fun compute(raw: List<TrackPoint>, startMs: Long, endMs: Long): SessionMetrics {
        val pts = mutableListOf<TrackPoint>()
        for (p in raw.sortedBy { it.timeMs }) {
            if (p.accuracyM > MAX_ACCURACY_M) continue
            val prev = pts.lastOrNull()
            if (prev != null && prev.segment == p.segment) {
                val dt = (p.timeMs - prev.timeMs) / 1000.0
                if (dt <= 0) continue
                if (haversineM(prev, p) / dt > MAX_SPEED_MS) continue
            }
            pts += p
        }
        var dist = 0.0; var active = 0L; var lost = 0L
        val windows = mutableListOf<Double>()
        for ((_, seg) in pts.groupBy { it.segment }) {
            if (seg.size < 2) continue
            active += seg.last().timeMs - seg.first().timeMs
            var anchor = seg.first()
            for (i in 1 until seg.size) {
                val a = seg[i - 1]; val b = seg[i]
                if (b.timeMs - a.timeMs > GAP_MS) { lost += b.timeMs - a.timeMs; anchor = b; continue }
                dist += haversineM(a, b)
                if (b.timeMs - anchor.timeMs >= WINDOW_MS) {
                    windows += haversineM(anchor, b) / ((b.timeMs - anchor.timeMs) / 1000.0); anchor = b
                }
            }
        }
        active -= lost
        val enough = windows.size >= 3
        val moving = windows.filter { it >= MOVING_MS }
        val avg = if (active > 0 && dist > 0) dist / (active / 1000.0) else null
        return SessionMetrics(
            dist, max(0, endMs - startMs), max(0, active),
            avg?.times(3.6),
            if (enough) windows.max() * 3.6 else null,
            if (enough && moving.isNotEmpty()) moving.min() * 3.6 else null,
            if (avg != null) 1000.0 / avg else null, lost
        )
    }

    /** Ritmo agregado correcto: distancia y tiempo acumulados, no media de ritmos. */
    fun aggregatePaceSecPerKm(list: List<SessionMetrics>): Double? {
        val d = list.sumOf { it.distanceM }; val t = list.sumOf { it.activeMs }
        return if (d > 0) (t / 1000.0) / (d / 1000.0) else null
    }
}
