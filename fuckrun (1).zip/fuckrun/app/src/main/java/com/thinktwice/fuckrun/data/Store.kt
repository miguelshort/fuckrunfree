package com.thinktwice.fuckrun.data
import android.content.Context
import com.thinktwice.fuckrun.tracking.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.*
import java.io.File
import java.time.*

data class Act(val id: String, val startMs: Long, val endMs: Long, val distanceM: Double, val activeMs: Long,
    val avgKmh: Double?, val maxKmh: Double?, val minKmh: Double?, val lostMs: Long, val manual: Boolean, val note: String, val plannedId: String?)
data class Planned(val id: String, val name: String, val epochDay: Long, val type: String, val targetMin: Int,
    val intensity: String, val rest: Boolean, val doneActId: String?)
data class Profile(val goal: String = "", val runsNow: String = "", val runsPerWeek: Int = 0, val comfortMin: Int = -1,
    val usualKm: String = "No lo sé", val sessionMin: Int = 30, val daysWanted: Int = 3, val days: Set<Int> = setOf(1, 3, 6),
    val mode: String = "Ambas", val terrain: String = "Parques", val flat: String = "Llano", val shape: String = "Circular",
    val town: String = "", val province: String = "", val limitation: String = "")
data class Meetup(val id: String, val name: String, val town: String, val whenText: String, val distance: String, val notes: String)

fun Act.date(): LocalDate = Instant.ofEpochMilli(startMs).atZone(ZoneId.systemDefault()).toLocalDate()

/** Almacenamiento PERSONAL (solo local, JSON en filesDir). Nada sale del dispositivo. */
object Store {
    private lateinit var dir: File
    val acts = MutableStateFlow<List<Act>>(emptyList())
    val planned = MutableStateFlow<List<Planned>>(emptyList())
    val profile = MutableStateFlow<Profile?>(null)
    val meetups = MutableStateFlow<List<Meetup>>(emptyList())
    // Sesión terminada pendiente de guardar/descartar (o recuperada tras un cierre)
    val pendingSave = MutableStateFlow(false)
    var endMs = 0L
    var recovered = false

    fun init(c: Context) {
        dir = c.filesDir
        acts.value = readArr("acts.json").map { o -> Act(o.getString("id"), o.getLong("s"), o.getLong("e"), o.getDouble("d"), o.getLong("a"),
            n(o, "avg"), n(o, "max"), n(o, "min"), o.getLong("lost"), o.getBoolean("man"), o.getString("note"), o.optString("pl").ifEmpty { null }) }
        planned.value = readArr("planned.json").map { o -> Planned(o.getString("id"), o.getString("n"), o.getLong("day"), o.getString("t"),
            o.getInt("min"), o.getString("i"), o.getBoolean("rest"), o.optString("done").ifEmpty { null }) }
        meetups.value = readArr("meetups.json").map { o -> Meetup(o.getString("id"), o.getString("n"), o.getString("t"), o.getString("w"), o.getString("d"), o.getString("x")) }
        File(dir, "profile.json").takeIf { it.exists() }?.let { f -> runCatching { val o = JSONObject(f.readText())
            profile.value = Profile(o.getString("goal"), o.getString("runs"), o.getInt("rpw"), o.getInt("comf"), o.getString("km"), o.getInt("smin"),
                o.getInt("dw"), o.getString("days").split(",").filter { it.isNotEmpty() }.map { it.toInt() }.toSet(), o.getString("mode"), o.getString("ter"),
                o.getString("flat"), o.getString("shape"), o.getString("town"), o.getString("prov"), o.getString("lim")) } }
        // Recuperación tras cierre inesperado del proceso
        val j = File(dir, "active_session.csv")
        if (com.thinktwice.fuckrun.tracking.TrackingState.status.value == TrackingState.Status.IDLE && j.exists() && j.length() > 0) {
            val pts = readPoints(j)
            if (pts.size >= 2) { TrackingState.points.value = pts; TrackingState.startMs = pts.first().timeMs
                endMs = pts.last().timeMs; recovered = true; pendingSave.value = true }
        }
    }
    private fun n(o: JSONObject, k: String) = if (o.isNull(k)) null else o.getDouble(k)
    private fun readArr(f: String): List<JSONObject> = File(dir, f).takeIf { it.exists() }?.let {
        runCatching { JSONArray(it.readText()).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i) } } }.getOrNull() } ?: emptyList()

    private fun persistActs() = File(dir, "acts.json").writeText(JSONArray(acts.value.map { a -> JSONObject().put("id", a.id).put("s", a.startMs).put("e", a.endMs)
        .put("d", a.distanceM).put("a", a.activeMs).put("avg", a.avgKmh ?: JSONObject.NULL).put("max", a.maxKmh ?: JSONObject.NULL)
        .put("min", a.minKmh ?: JSONObject.NULL).put("lost", a.lostMs).put("man", a.manual).put("note", a.note).put("pl", a.plannedId ?: "") }).toString())
    private fun persistPlanned() = File(dir, "planned.json").writeText(JSONArray(planned.value.map { p -> JSONObject().put("id", p.id).put("n", p.name)
        .put("day", p.epochDay).put("t", p.type).put("min", p.targetMin).put("i", p.intensity).put("rest", p.rest).put("done", p.doneActId ?: "") }).toString())
    private fun persistMeetups() = File(dir, "meetups.json").writeText(JSONArray(meetups.value.map { m -> JSONObject().put("id", m.id).put("n", m.name)
        .put("t", m.town).put("w", m.whenText).put("d", m.distance).put("x", m.notes) }).toString())

    fun saveProfile(p: Profile) { profile.value = p
        File(dir, "profile.json").writeText(JSONObject().put("goal", p.goal).put("runs", p.runsNow).put("rpw", p.runsPerWeek).put("comf", p.comfortMin)
            .put("km", p.usualKm).put("smin", p.sessionMin).put("dw", p.daysWanted).put("days", p.days.joinToString(",")).put("mode", p.mode)
            .put("ter", p.terrain).put("flat", p.flat).put("shape", p.shape).put("town", p.town).put("prov", p.province).put("lim", p.limitation).toString()) }

    fun addAct(a: Act, pts: List<TrackPoint>) {
        if (pts.isNotEmpty()) File(dir, "pts_${a.id}.csv").writeText(pts.joinToString("\n") { "${it.timeMs},${it.lat},${it.lon},${it.accuracyM},${it.segment}" })
        acts.value = acts.value + a; persistActs()
        if (a.plannedId != null) { planned.value = planned.value.map { if (it.id == a.plannedId && it.doneActId == null) it.copy(doneActId = a.id) else it }; persistPlanned() }
    }
    fun deleteAct(id: String) { acts.value = acts.value.filter { it.id != id }; persistActs(); File(dir, "pts_$id.csv").delete()
        planned.value = planned.value.map { if (it.doneActId == id) it.copy(doneActId = null) else it }; persistPlanned() }
    fun updateNote(id: String, note: String) { acts.value = acts.value.map { if (it.id == id) it.copy(note = note) else it }; persistActs() }
    fun points(id: String): List<TrackPoint> = File(dir, "pts_$id.csv").takeIf { it.exists() }?.let { readPoints(it) } ?: emptyList()
    private fun readPoints(f: File) = f.readLines().mapNotNull { l -> runCatching { l.split(",").let { TrackPoint(it[0].toLong(), it[1].toDouble(), it[2].toDouble(), it[3].toFloat(), it[4].toInt()) } }.getOrNull() }
    fun clearJournal() { File(dir, "active_session.csv").writeText(""); recovered = false; pendingSave.value = false; TrackingState.points.value = emptyList() }

    fun addPlanned(list: List<Planned>) { planned.value = planned.value + list; persistPlanned() }
    fun deletePlanned(id: String) { planned.value = planned.value.filter { it.id != id }; persistPlanned() }
    fun shiftPlanned(id: String, days: Int) { planned.value = planned.value.map { if (it.id == id && it.doneActId == null) it.copy(epochDay = it.epochDay + days) else it }; persistPlanned() }
    fun addMeetup(m: Meetup) { meetups.value = meetups.value + m; persistMeetups() }

    fun exportAllJson(): String = JSONObject().put("formato", "fuckrun-export-v1")
        .put("actividades", JSONArray(acts.value.map { a -> JSONObject().put("id", a.id).put("inicio_ms", a.startMs).put("fin_ms", a.endMs).put("distancia_m", a.distanceM)
            .put("tiempo_activo_ms", a.activeMs).put("vel_media_kmh", a.avgKmh ?: JSONObject.NULL).put("vel_max_kmh", a.maxKmh ?: JSONObject.NULL)
            .put("vel_min_mov_kmh", a.minKmh ?: JSONObject.NULL).put("manual", a.manual).put("nota", a.note) }))
        .put("sesiones_planificadas", JSONArray(planned.value.map { p -> JSONObject().put("nombre", p.name).put("dia_epoch", p.epochDay).put("tipo", p.type).put("min", p.targetMin) })).toString(2)
    fun deleteAll() { dir.listFiles()?.forEach { it.delete() }; acts.value = emptyList(); planned.value = emptyList(); meetups.value = emptyList(); profile.value = null; pendingSave.value = false }

    fun gpx(a: Act): String {
        val pts = points(a.id); val sb = StringBuilder("""<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="fuckrun" xmlns="http://www.topografix.com/GPX/1/1"><trk><name>fuckrun ${a.id.take(8)}</name>""")
        pts.groupBy { it.segment }.forEach { (_, s) -> sb.append("<trkseg>"); s.forEach { sb.append("<trkpt lat=\"${it.lat}\" lon=\"${it.lon}\"><time>${Instant.ofEpochMilli(it.timeMs)}</time></trkpt>") }; sb.append("</trkseg>") }
        return sb.append("</trk></gpx>").toString()
    }
}
