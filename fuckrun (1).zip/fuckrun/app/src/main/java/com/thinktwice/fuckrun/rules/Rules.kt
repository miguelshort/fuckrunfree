package com.thinktwice.fuckrun.rules
import com.thinktwice.fuckrun.data.Profile

/**
 * Reglas explícitas, sin IA. Procedencia: plantillas propias de thinktwice basadas en el enfoque general de
 * progresión por tiempo alternando caminar/correr. NO son un programa clínico, no garantizan resultados y están
 * PENDIENTES de revisión por una persona entrenadora cualificada antes de publicarse.
 */
object Rules {
    enum class Level(val label: String) { INICIO("Inicio"), BASE("Base"), CONTINUIDAD("Continuidad") }
    data class Tpl(val name: String, val type: String, val minutes: Int, val intensity: String, val detail: String, val used: String, val epochDay: Long)
    data class Result(val level: Level, val why: String, val sessions: List<Tpl>, val notes: List<String>)

    fun level(p: Profile): Pair<Level, String> = when {
        p.runsNow == "No" -> Level.INICIO to "Has indicado que ahora no corres."
        p.comfortMin in 0..4 -> Level.INICIO to "Puedes correr seguido menos de 5 minutos con comodidad."
        p.runsNow == "Sí" && p.comfortMin >= 20 && p.runsPerWeek >= 2 -> Level.CONTINUIDAD to "Corres ${p.runsPerWeek} días por semana y puedes mantener ${p.comfortMin} min seguidos."
        p.runsNow == "Sí" -> Level.BASE to (if (p.comfortMin < 0) "No sabes cuánto aguantas seguido; empezamos de forma prudente." else "Puedes correr ${p.comfortMin} min seguidos, o corres menos de 2 días por semana.")
        else -> Level.INICIO to "Sin datos suficientes de experiencia: punto de partida prudente."
    }

    fun recommend(p: Profile, tomorrowEpoch: Long, tomorrowDow: Int): Result {
        val (lvl, why) = level(p)
        val m = p.sessionMin.coerceIn(15, 90)
        val notes = mutableListOf("Orientativo y editable. No es una evaluación médica ni un resultado exacto.",
            "No se aumenta la carga automáticamente por completar sesiones.")
        if (p.limitation.isNotBlank()) notes += "Has indicado una limitación: no se propone intensificar. Puedes sustituir cualquier sesión por descanso o la actividad que te hayan indicado."
        val main = if (lvl == Level.INICIO) m.coerceAtMost(30) else if (p.limitation.isNotBlank()) m.coerceAtMost(40) else m
        val days = (if (p.days.isEmpty()) setOf(1, 3, 6) else p.days).sorted().take(p.daysWanted.coerceAtLeast(1))
        val c = if (p.comfortMin > 0) p.comfortMin.coerceAtMost(15) else 3
        val (name, intensity, body) = when (lvl) {
            Level.INICIO -> Triple("Alternar caminar y correr", "Muy suave: podrías hablar con frases completas",
                "Calentamiento: 5 min caminando. Alterna 1 min trotando suave y 2 min caminando durante ${main - 10} min. Vuelta a la calma: 5 min caminando. Descansos: los tramos caminando.")
            Level.BASE -> Triple("Bloques suaves", "Suave: ritmo cómodo y conversacional",
                "Calentamiento: 5 min caminando. Bloques de $c min corriendo suave con 2 min caminando hasta completar ${main - 10} min. Vuelta a la calma: 5 min caminando.")
            Level.CONTINUIDAD -> Triple("Rodaje suave", "Suave a moderada: sin llegar a ir sin aliento",
                "Calentamiento: 5 min caminando o trote muy suave. Rodaje continuo de ${main - 10} min. Vuelta a la calma: 5 min caminando. Pausas cortas si las necesitas.")
        }
        val used = "Nivel (${lvl.label}), ${p.daysWanted} días deseados, ${p.sessionMin} min por sesión" + (if (p.comfortMin > 0) ", ${p.comfortMin} min seguidos" else "")
        val sessions = days.map { d -> val delta = ((d - tomorrowDow) + 7) % 7
            Tpl(name, name, main, intensity, body, used, tomorrowEpoch + delta) }
        return Result(lvl, why, sessions, notes)
    }
}
