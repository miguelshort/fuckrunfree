package com.thinktwice.fuckrun.ui
import android.Manifest
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thinktwice.fuckrun.R
import com.thinktwice.fuckrun.data.*
import com.thinktwice.fuckrun.tracking.*
import java.time.*
import java.util.UUID

sealed class Nav { object Onb : Nav(); object Plan : Nav(); object Manual : Nav(); object NewMeet : Nav(); object NewPlanned : Nav(); object Profile : Nav(); class Detail(val id: String) : Nav() }

private fun today() = LocalDate.now()
private fun status(p: Planned) = when { p.rest -> "Descanso"; p.doneActId != null -> "Completada"; p.epochDay < today().toEpochDay() -> "Vencida"; else -> "Pendiente" }

@Composable fun HomeScreen(nav: (Nav) -> Unit) {
    val ctx = LocalContext.current
    val acts by Store.acts.collectAsStateWithLifecycle(); val planned by Store.planned.collectAsStateWithLifecycle()
    val monday = today().with(DayOfWeek.MONDAY)
    val week = acts.filter { !it.date().isBefore(monday) }
    val next = planned.filter { !it.rest && it.doneActId == null && it.epochDay >= today().toEpochDay() }.minByOrNull { it.epochDay }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true || r[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
            ctx.startForegroundService(Intent(ctx, TrackingService::class.java).setAction(TrackingService.START))
        else Toast.makeText(ctx, "Sin permiso de ubicación no se puede registrar la ruta.", Toast.LENGTH_LONG).show() }
    Screen(null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo_fkrun), "fuckrun", Modifier.height(64.dp).weight(1f), contentScale = androidx.compose.ui.layout.ContentScale.Fit, alignment = Alignment.CenterStart)
            IconButton({ nav(Nav.Profile) }) { Icon(Icons.Filled.Person, "Perfil y ajustes", tint = C.Text) } }
        Text("Tu semana", style = Title)
        Text("%.1f km".format(week.sumOf { it.distanceM } / 1000), style = BigNumber.copy(fontSize = 48.sp))
        Text("${week.size} sesiones · ${fmtDur(week.sumOf { it.activeMs })} de tiempo activo", color = C.TextDim)
        if (next != null) InfoCard("Próxima sesión: ${next.name}", "${LocalDate.ofEpochDay(next.epochDay)} · ${next.targetMin} min · ${next.intensity}")
        else if (Store.profile.value == null) { InfoCard("Personaliza tu inicio", "Responde un formulario breve para recibir una propuesta. Sin IA, con reglas que puedes revisar.")
            Pill("Rellenar formulario", C.Blue) { nav(Nav.Onb) } }
        else InfoCard("Sin sesiones planificadas", "Crea una rutina desde Rutinas.")
        Text("La ubicación se usa solo durante una sesión iniciada, para dibujar tu ruta y medir distancia.", color = C.TextDim, fontSize = 13.sp)
        Pill("Empezar a correr", C.Green) { perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun SessionScreen() {
    val ctx = LocalContext.current
    val status by TrackingState.status.collectAsStateWithLifecycle(); val pts by TrackingState.points.collectAsStateWithLifecycle()
    val acc by TrackingState.lastAccuracy.collectAsStateWithLifecycle()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }; var confirmEnd by remember { mutableStateOf(false) }; var locked by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
    val m = MetricsCalculator.compute(pts, TrackingState.startMs, now)
    fun send(a: String) = ctx.startService(Intent(ctx, TrackingService::class.java).setAction(a))
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (status == TrackingState.Status.PAUSED) "En pausa" else "Grabando", color = C.TextDim)
        Text("%.2f km".format(m.distanceM / 1000), style = BigNumber)
        Text("Tiempo activo  ${fmtDur(m.activeMs)}", style = Title.copy(fontSize = 22.sp))
        Text("Transcurrido (con pausas)  ${fmtDur(m.elapsedMs)}", color = C.TextDim)
        Text("Vel. media  ${fmtKmh(m.avgSpeedKmh)}", color = C.Text); Text("Ritmo medio  ${fmtPace(m.avgPaceSecPerKm)}", color = C.Text)
        Text("Máx  ${fmtKmh(m.maxSpeedKmh)}   ·   Mín en mov.  ${fmtKmh(m.minMovingSpeedKmh)}", color = C.TextDim)
        Text(when { acc == null -> "Señal GPS: buscando…"; acc!! <= 10 -> "Señal GPS: buena"; acc!! <= 25 -> "Señal GPS: aceptable"; else -> "Señal GPS: débil (puntos descartados)" }, color = C.TextDim, fontSize = 13.sp)
        if (m.lostGapMs > 0) Text("Hay tramos sin datos: no se muestran como recorrido confirmado.", color = C.Red, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        when {
            locked -> Box(Modifier.fillMaxWidth().height(64.dp).background(C.Control, androidx.compose.foundation.shape.RoundedCornerShape(50))
                .combinedClickable(onClick = {}, onLongClick = { locked = false }), contentAlignment = Alignment.Center) { Text("Controles bloqueados · mantén pulsado para desbloquear", color = C.Text, fontSize = 14.sp) }
            confirmEnd -> { Text("¿Terminar la sesión?", style = Title.copy(fontSize = 22.sp))
                Pill("Sí, terminar", C.Blue) { Store.endMs = System.currentTimeMillis(); Store.pendingSave.value = true; send(TrackingService.STOP); confirmEnd = false }
                Pill("Seguir corriendo", C.Control, textColor = C.Text) { confirmEnd = false } }
            else -> { if (status == TrackingState.Status.RUNNING) Pill("⏸  Pausar", C.Red) { send(TrackingService.PAUSE) } else Pill("▶  Reanudar", C.Green) { send(TrackingService.RESUME) }
                Pill("Terminar", C.Blue) { confirmEnd = true }; Pill("Bloquear controles", C.Control, textColor = C.Text) { locked = true } }
        }
    }
}

@Composable fun SaveScreen() {
    val ctx = LocalContext.current
    val pts by TrackingState.points.collectAsStateWithLifecycle(); val planned by Store.planned.collectAsStateWithLifecycle()
    val m = remember(pts) { MetricsCalculator.compute(pts, TrackingState.startMs, Store.endMs) }
    var note by remember { mutableStateOf("") }; var sel by remember { mutableStateOf("Ninguna") }; var askDiscard by remember { mutableStateOf(false) }
    val cands = planned.filter { !it.rest && it.doneActId == null && it.epochDay <= today().toEpochDay() + 1 }
    val labels = cands.associateBy { "${it.name} · ${LocalDate.ofEpochDay(it.epochDay)}" }
    Screen("Resumen de la sesión") {
        if (Store.recovered) InfoCard("Sesión recuperada", "La app se cerró durante la grabación. Se recupera lo registrado; puede faltar el último tramo.")
        Text("%.2f km".format(m.distanceM / 1000), style = BigNumber)
        InfoCard("Tiempos", "Transcurrido ${fmtDur(m.elapsedMs)} · Activo ${fmtDur(m.activeMs)}")
        InfoCard("Velocidad y ritmo", "Media ${fmtKmh(m.avgSpeedKmh)} · Máx ${fmtKmh(m.maxSpeedKmh)} · Mín en mov. ${fmtKmh(m.minMovingSpeedKmh)} · Ritmo ${fmtPace(m.avgPaceSecPerKm)}")
        if (m.lostGapMs > 0) InfoCard("Tramos sin datos", "${m.lostGapMs / 1000} s sin señal válida; no se cuentan en distancia.")
        RouteCanvas(pts, Modifier.fillMaxWidth().height(220.dp).background(C.Surface2, androidx.compose.foundation.shape.RoundedCornerShape(22.dp)))
        Text("Inicio ● verde · Fin ■ blanco · Tramos sin datos: línea discontinua. (Sin mapa base: falta proveedor.)", color = C.TextDim, fontSize = 12.sp)
        OutlinedTextField(note, { note = it }, label = { Text("Nota privada (opcional)") }, modifier = Modifier.fillMaxWidth())
        if (cands.isNotEmpty()) { Text("¿Vincular a una sesión planificada?", color = C.Text); Chips(listOf("Ninguna") + labels.keys, sel) { sel = it } }
        Pill("Guardar", C.Green) {
            val a = Act(UUID.randomUUID().toString(), TrackingState.startMs, Store.endMs, m.distanceM, m.activeMs, m.avgSpeedKmh, m.maxSpeedKmh, m.minMovingSpeedKmh, m.lostGapMs, false, note, labels[sel]?.id)
            Store.addAct(a, pts); Store.clearJournal(); Toast.makeText(ctx, "Sesión guardada", Toast.LENGTH_SHORT).show() }
        Pill("Descartar", C.Control, textColor = C.Red) { askDiscard = true }
    }
    if (askDiscard) Confirm("¿Descartar la sesión?", "Se perderá el registro y no se podrá recuperar.", "Descartar", { Store.clearJournal(); askDiscard = false }, { askDiscard = false })
}

@Composable fun ProgressScreen(nav: (Nav) -> Unit) {
    val acts by Store.acts.collectAsStateWithLifecycle(); var period by remember { mutableStateOf("Semana") }
    val t = today()
    val from = when (period) { "Semana" -> t.with(DayOfWeek.MONDAY); "Mes" -> t.withDayOfMonth(1); else -> t.withDayOfYear(1) }
    val inP = acts.filter { !it.date().isBefore(from) }
    val nb = when (period) { "Semana" -> 7; "Mes" -> t.lengthOfMonth(); else -> 12 }
    val vals = DoubleArray(nb); inP.forEach { a -> val i = when (period) { "Semana" -> a.date().dayOfWeek.value - 1; "Mes" -> a.date().dayOfMonth - 1; else -> a.date().monthValue - 1 }; if (i in 0 until nb) vals[i] += a.distanceM / 1000 }
    val labels = (0 until nb).map { i -> when (period) { "Semana" -> listOf("L", "M", "X", "J", "V", "S", "D")[i]; "Mes" -> if ((i + 1) % 5 == 0 || i == 0) "${i + 1}" else ""; else -> "EFMAMJJASOND"[i].toString() } }
    val measured = inP.filter { !it.manual }
    val pace = measured.sumOf { it.distanceM }.let { d -> if (d > 0) measured.sumOf { it.activeMs } / 1000.0 / (d / 1000) else null }
    Screen("Progreso") {
        Chips(listOf("Semana", "Mes", "Año"), period) { period = it }
        Text("%.1f km".format(inP.sumOf { it.distanceM } / 1000), style = BigNumber.copy(fontSize = 48.sp))
        Bars(vals.toList(), labels)
        InfoCard("${inP.size} sesiones · ${fmtDur(inP.sumOf { it.activeMs })} activo", "Duración media: " + (if (inP.isEmpty()) "Sin datos" else fmtDur(inP.sumOf { it.activeMs } / inP.size)) +
            "\nRitmo agregado (solo registros medidos): ${fmtPace(pace)}\nUn ritmo más rápido no implica mejora: depende de distancia, terreno y tipo de sesión.")
        Pill("Añadir actividad manual", C.Control, textColor = C.Text) { nav(Nav.Manual) }
        Text("Historial privado", style = Title.copy(fontSize = 22.sp))
        if (acts.isEmpty()) InfoCard("Sin actividades", "Cuando guardes tu primera sesión aparecerá aquí.")
        acts.sortedByDescending { it.startMs }.forEach { a -> Row(Modifier.fillMaxWidth().clickable { nav(Nav.Detail(a.id)) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(a.date().toString(), color = C.Text); Text(if (a.manual) "Manual · sin GPS" else "Medida con GPS", color = C.TextDim, fontSize = 13.sp) }
            Text("%.2f km".format(a.distanceM / 1000), color = C.Text, style = Title.copy(fontSize = 18.sp)) } }
    }
}

@Composable fun ActDetail(id: String, back: () -> Unit) {
    val ctx = LocalContext.current; val a = Store.acts.value.firstOrNull { it.id == id }
    var note by remember { mutableStateOf(a?.note ?: "") }; var askDel by remember { mutableStateOf(false) }; var askShare by remember { mutableStateOf(false) }
    if (a == null) { back(); return }
    val pts = remember(id) { Store.points(id) }; val sp = remember(pts) { Splits.perKm(pts) }
    Screen("Detalle · ${a.date()}") {
        Text("%.2f km".format(a.distanceM / 1000), style = BigNumber)
        InfoCard(if (a.manual) "Actividad manual (introducida a mano)" else "Registro medido con GPS", "Activo ${fmtDur(a.activeMs)} · Transcurrido ${fmtDur(a.endMs - a.startMs)}\nVel. media ${fmtKmh(a.avgKmh)} · Máx ${fmtKmh(a.maxKmh)} · Mín en mov. ${fmtKmh(a.minKmh)}")
        if (pts.isNotEmpty()) RouteCanvas(pts, Modifier.fillMaxWidth().height(220.dp).background(C.Surface2, androidx.compose.foundation.shape.RoundedCornerShape(22.dp)))
        if (sp.isNotEmpty()) InfoCard("Parciales por km", sp.mapIndexed { i, ms -> "Km ${i + 1}: ${fmtPace(ms / 1000.0)}" }.joinToString("\n")) else if (!a.manual) InfoCard("Parciales por km", "Sin datos suficientes.")
        OutlinedTextField(note, { note = it; Store.updateNote(id, it) }, label = { Text("Nota privada") }, modifier = Modifier.fillMaxWidth())
        if (!a.manual) Pill("Exportar GPX", C.Blue) { askShare = true }
        Pill("Eliminar actividad", C.Control, textColor = C.Red) { askDel = true }
    }
    if (askDel) Confirm("¿Eliminar actividad?", "Se borrará también su recorrido.", "Eliminar", { Store.deleteAct(id); back() }, { askDel = false })
    if (askShare) Confirm("Antes de compartir", "Un archivo de ruta puede revelar dónde vives, trabajas o corres habitualmente.", "Continuar", {
        askShare = false; ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/gpx+xml").putExtra(Intent.EXTRA_TEXT, Store.gpx(a)), "Exportar GPX")) }, { askShare = false })
}

@Composable fun ManualScreen(back: () -> Unit) {
    var km by remember { mutableStateOf("") }; var min by remember { mutableStateOf("") }
    val d = km.replace(',', '.').toDoubleOrNull(); val mi = min.toIntOrNull()
    Screen("Actividad manual") {
        InfoCard("Sin GPS", "Se guardará marcada como manual, sin ruta ni velocidades máxima/mínima.")
        Field("Distancia (km)", km, true) { km = it }; Field("Duración (min)", min, true) { min = it }
        Pill("Guardar", C.Green, enabled = d != null && d > 0 && mi != null && mi > 0) {
            val now = System.currentTimeMillis(); val ms = mi!! * 60000L
            Store.addAct(Act(UUID.randomUUID().toString(), now - ms, now, d!! * 1000, ms, d / (mi / 60.0), null, null, 0, true, "", null), emptyList()); back() }
    }
}
