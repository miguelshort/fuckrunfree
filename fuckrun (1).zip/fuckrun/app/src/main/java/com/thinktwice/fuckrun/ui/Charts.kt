package com.thinktwice.fuckrun.ui
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thinktwice.fuckrun.tracking.*
import kotlin.math.cos
import kotlin.math.min

/** Barras en azul #6C8CFF. */
@Composable fun Bars(values: List<Double>, labels: List<String>) {
    val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(0.0001)
    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val w = size.width / values.size.coerceAtLeast(1)
            values.forEachIndexed { i, v -> if (v > 0) { val h = (v / max * size.height).toFloat().coerceAtLeast(4f)
                drawRoundRect(C.Blue, Offset(i * w + w * 0.2f, size.height - h), Size(w * 0.6f, h), CornerRadius(6f, 6f)) } }
        }
        Row(Modifier.fillMaxWidth()) { labels.forEach { Text(it, Modifier.weight(1f), color = C.TextDim, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1) } }
    }
}

/** Verde: completadas · Rojo: vencidas no completadas · Gris: pendientes/futuras. */
@Composable fun Donut(done: Int, over: Int, pend: Int) {
    val total = done + over + pend
    Canvas(Modifier.size(130.dp)) {
        val st = Stroke(26f); val sz = Size(size.width - 26f, size.height - 26f); val tl = Offset(13f, 13f); var start = -90f
        if (total == 0) drawArc(C.Control, 0f, 360f, false, tl, sz, style = st)
        fun arc(n: Int, c: Color) { if (n == 0) return; val sw = 360f * n / total; drawArc(c, start, (sw - 2f).coerceAtLeast(1f), false, tl, sz, style = st); start += sw }
        arc(done, C.Green); arc(over, C.Red); arc(pend, Color(0xFF6B7280))
    }
}

/** Trazado sin mapa base (requiere proveedor cartográfico, pendiente). Huecos: línea discontinua gris. Inicio: círculo verde. Fin: cuadrado blanco. */
@Composable fun RouteCanvas(pts: List<TrackPoint>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val v = pts.filter { it.accuracyM <= MetricsCalculator.MAX_ACCURACY_M }
        if (v.size < 2) return@Canvas
        val midLat = Math.toRadians((v.minOf { it.lat } + v.maxOf { it.lat }) / 2); val k = cos(midLat)
        val minLon = v.minOf { it.lon }; val maxLat = v.maxOf { it.lat }
        val dx = ((v.maxOf { it.lon } - minLon) * k).coerceAtLeast(1e-7); val dy = (maxLat - v.minOf { it.lat }).coerceAtLeast(1e-7)
        val sc = min((size.width - 48f) / dx, (size.height - 48f) / dy).toFloat()
        fun o(p: TrackPoint) = Offset(24f + ((p.lon - minLon) * k * sc).toFloat(), 24f + ((maxLat - p.lat) * sc).toFloat())
        for (i in 1 until v.size) { val a = v[i - 1]; val b = v[i]; if (a.segment != b.segment) continue
            if (b.timeMs - a.timeMs > MetricsCalculator.GAP_MS) drawLine(Color(0xFF6B7280), o(a), o(b), 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f)))
            else drawLine(C.Blue, o(a), o(b), 7f, StrokeCap.Round) }
        drawCircle(C.Green, 13f, o(v.first())); val e = o(v.last()); drawRect(Color.White, Offset(e.x - 11, e.y - 11), Size(22f, 22f))
    }
}
