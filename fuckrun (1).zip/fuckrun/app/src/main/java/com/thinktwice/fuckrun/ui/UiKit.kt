package com.thinktwice.fuckrun.ui
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun Screen(title: String?, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 130.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)) { if (title != null) Text(title, style = Title); content() }

@Composable fun InfoCard(title: String, body: String, modifier: Modifier = Modifier) = Column(modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.Card).padding(18.dp)) {
    Text(title, fontWeight = FontWeight.Bold, color = C.Text); if (body.isNotEmpty()) Text(body, color = C.TextDim, fontSize = 14.sp) }

@Composable fun Pill(text: String, bg: Color, modifier: Modifier = Modifier, textColor: Color = Color(0xFF0B0C0F), enabled: Boolean = true, onClick: () -> Unit) =
    Box(modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(50)).background(if (enabled) bg else C.Control).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (enabled) textColor else C.TextDim) }

@OptIn(ExperimentalLayoutApi::class)
@Composable fun Chips(opts: List<String>, sel: String, on: (String) -> Unit) = FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    opts.forEach { o -> val s = o == sel
        Text(o, color = if (s) Color(0xFF0B0C0F) else C.Text, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(if (s) C.Blue else C.Control)
            .clickable { on(o) }.padding(horizontal = 16.dp, vertical = 10.dp)) } }

@Composable fun Field(label: String, value: String, num: Boolean = false, onChange: (String) -> Unit) = OutlinedTextField(value, onChange, label = { Text(label) },
    modifier = Modifier.fillMaxWidth(), singleLine = true,
    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text),
    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.Text, unfocusedTextColor = C.Text, focusedBorderColor = C.Blue, unfocusedBorderColor = C.Control,
        focusedLabelColor = C.Blue, unfocusedLabelColor = C.TextDim))

@Composable fun Confirm(title: String, body: String, ok: String, onOk: () -> Unit, onCancel: () -> Unit) = AlertDialog(onDismissRequest = onCancel,
    containerColor = C.Surface2, title = { Text(title, color = C.Text) }, text = { Text(body, color = C.TextDim) },
    confirmButton = { TextButton(onOk) { Text(ok, color = C.Blue) } }, dismissButton = { TextButton(onCancel) { Text("Cancelar", color = C.TextDim) } })

fun fmtDur(ms: Long) = "%02d:%02d:%02d".format(ms / 3600000, ms / 60000 % 60, ms / 1000 % 60)
fun fmtPace(s: Double?) = s?.let { "%d:%02d min/km".format((it / 60).toInt(), (it % 60).toInt()) } ?: "Sin datos"
fun fmtKmh(v: Double?) = v?.let { "%.1f km/h".format(it) } ?: "Sin datos"
