package com.thinktwice.fuckrun
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thinktwice.fuckrun.data.Store
import com.thinktwice.fuckrun.tracking.TrackingState
import com.thinktwice.fuckrun.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); Store.init(this); setContent { FuckrunTheme { App() } } }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    Inicio("Inicio", Icons.Filled.Home), Rutas("Rutas", Icons.Filled.Map), Club("Club", Icons.Filled.Groups),
    Rutinas("Rutinas", Icons.Filled.CalendarMonth), Progreso("Progreso", Icons.Filled.BarChart)
}

@Composable private fun App() {
    var tab by remember { mutableStateOf(Tab.Inicio) }; var nav by remember { mutableStateOf<Nav?>(null) }
    val status by TrackingState.status.collectAsStateWithLifecycle(); val pending by Store.pendingSave.collectAsStateWithLifecycle()
    BackHandler(nav != null) { nav = null }
    Box(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding()) {
        when {
            status != TrackingState.Status.IDLE -> SessionScreen()           // navegación general oculta durante la carrera
            pending -> SaveScreen()
            nav != null -> {
                Column { TextButton({ nav = null }, Modifier.padding(start = 8.dp)) { Text("← Volver", color = C.Blue) }
                    Box(Modifier.weight(1f)) { when (val n = nav) {
                        Nav.Onb -> OnboardingScreen { nav = Nav.Plan }
                        Nav.Plan -> PlanScreen({ nav = null; tab = Tab.Rutinas }, { nav = Nav.Onb })
                        Nav.Manual -> ManualScreen { nav = null }
                        Nav.NewMeet -> NewMeetScreen { nav = null }
                        Nav.NewPlanned -> NewPlannedScreen { nav = null }
                        Nav.Profile -> ProfileScreen { nav = it }
                        is Nav.Detail -> ActDetail(n.id) { nav = null }
                        null -> {} } } } }
            else -> {
                when (tab) { Tab.Inicio -> HomeScreen { nav = it }; Tab.Rutas -> RoutesScreen { nav = Nav.Onb }; Tab.Club -> ClubScreen { nav = it }
                    Tab.Rutinas -> RoutinesScreen { nav = it }; Tab.Progreso -> ProgressScreen { nav = it } }
                CapsuleBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter)) }
        }
    }
}

@Composable private fun CapsuleBar(sel: Tab, onSel: (Tab) -> Unit, m: Modifier) {
    // Translúcida SIN desenfoque real todavía (pendiente: Haze / RenderEffect).
    Row(m.navigationBarsPadding().padding(start = 18.dp, end = 18.dp, bottom = 12.dp).fillMaxWidth().heightIn(min = 68.dp)
        .clip(RoundedCornerShape(50)).background(Color(0xE6151720)).border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(50)).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Tab.values().forEach { t -> val on = t == sel
            Column(Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (on) Color(0x26FFFFFF) else Color.Transparent).clickable { onSel(t) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally) { Icon(t.icon, null, tint = if (on) C.Text else C.TextDim); Text(t.label, fontSize = 12.sp, color = if (on) C.Text else C.TextDim) } }
    }
}
