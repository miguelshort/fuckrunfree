package com.thinktwice.fuckrun.tracking
import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.location.Location
import android.os.*
import com.google.android.gms.location.*
import kotlinx.coroutines.flow.*
import java.io.File

/** Estado observable de la sesión. Solo existe mientras haya una actividad iniciada. */
object TrackingState {
    enum class Status { IDLE, RUNNING, PAUSED }
    val status = MutableStateFlow(Status.IDLE)
    val points = MutableStateFlow<List<TrackPoint>>(emptyList())
    var startMs = 0L; var segment = 0
    val lastAccuracy = MutableStateFlow<Float?>(null)
}

class TrackingService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private lateinit var journal: File
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            for (l: Location in r.locations) {
                TrackingState.lastAccuracy.value = l.accuracy
                if (TrackingState.status.value != TrackingState.Status.RUNNING) continue
                val p = TrackPoint(l.time, l.latitude, l.longitude, l.accuracy, TrackingState.segment)
                TrackingState.points.value = TrackingState.points.value + p
                journal.appendText("${p.timeMs},${p.lat},${p.lon},${p.accuracyM},${p.segment}\n") // guardado incremental
            }
        }
        override fun onLocationAvailability(a: LocationAvailability) { if (!a.isLocationAvailable) TrackingState.lastAccuracy.value = null }
    }

    override fun onCreate() { super.onCreate(); client = LocationServices.getFusedLocationProviderClient(this)
        journal = File(filesDir, "active_session.csv") }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            START -> { TrackingState.points.value = emptyList(); TrackingState.segment = 0
                TrackingState.startMs = System.currentTimeMillis(); journal.writeText("")
                TrackingState.status.value = TrackingState.Status.RUNNING; foreground(); request() }
            PAUSE -> TrackingState.status.value = TrackingState.Status.PAUSED
            RESUME -> { TrackingState.segment++; TrackingState.status.value = TrackingState.Status.RUNNING }
            STOP -> { client.removeLocationUpdates(cb); TrackingState.status.value = TrackingState.Status.IDLE
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY // no rastrear fuera de una actividad iniciada
    }

    @SuppressLint("MissingPermission")
    private fun request() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000).setMinUpdateIntervalMillis(1000).build()
        try { client.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (_: SecurityException) { stopSelf() }
    }
    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("run", "Sesión activa", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "run").setContentTitle("fuckrun").setContentText("Sesión en curso")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build()
        startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
    }
    override fun onBind(i: Intent?): IBinder? = null
    companion object { const val START = "start"; const val PAUSE = "pause"; const val RESUME = "resume"; const val STOP = "stop" }
}
