package com.thinktwice.fuckrun.ui
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thinktwice.fuckrun.data.*
import com.thinktwice.fuckrun.rules.Rules
import java.time.*
import java.util.UUID

private fun st(p: Planned, t: Long) = when { p.rest -> "Descanso"; p.doneActId != null -> "Completada"; p.epochDay < t -> "Vencida"; else -> "Pendiente" }
private val DAYS = listOf("L", "M", "X", "J", "V", "S", "D")

@Composable fun RoutinesScreen(nav: (Nav) -> Unit) {
    val all by Store.planned.collectAsStateWithLifecycle(); var period by remember { mutableStateOf("Semana") }
    val t = LocalDate.now(); val today = t.toEpochDay()
    val from = if (period == "Semana") t.with(DayOfWeek.MONDAY) else t.withDayOfMonth(1)
    val to = if (period == "Semana") from.plusDays(6) else t.withDayOfMonth(t.lengthOfMonth())
    val list = all.filter { it.epochDay in from.toEpochDay()..to.toEpochDay() }.sortedBy { it.epochDay }
    val tr = list.filter { !it.rest }
    val done = tr.count { st(it, today) == "Completada" }; val over = tr.count { st(it, today) == "Vencida" }; val pend = tr.size - done - over
    Screen("Rutinas") {
        Chips(listOf("Semana", "Mes"), period) { period = it }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Donut(done, over, pend)
            Column { Text("Completadas: $done", color = C.Green); Text("Vencidas sin completar: $over", color = C.Red); Text("Pendientes o futuras: $pend", color = C.TextDim)
                Text("Periodo: $from – $to", color = C.TextDim, fontSize = 12.sp); Text("Los descansos no cuentan como incumplidos.", color = C.TextDim, fontSize = 12.sp) } }
        Pill("Crear desde mi plan", C.Blue) { nav(if (Store.profile.value == null) Nav.Onb else Nav.Plan) }
        Pill("Añadir sesión o descanso", C.Control, textColor = C.Text) { nav(Nav.NewPlanned) }
        if (list.isEmpty()) InfoCard("Sin rutina en este periodo", "Crea una desde tu plan o añade sesiones a mano.")
        list.forEach { p -> val s = st(p, today)
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${p.name} · ${LocalDate.ofEpochDay(p.epochDay)}", color = C.Text)
                Text("$s${if (!p.rest) " · ${p.targetMin} min · ${p.intensity}" else ""}", color = when (s) { "Completada" -> C.Green; "Vencida" -> C.Red; else -> C.TextDim }, fontSize = 13.sp)
                if (p.doneActId == null) Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    TextButton({ Store.shiftPlanned(p.id, 1) }) { Text("Posponer 1 día", color = C.Blue) }
                    TextButton({ Store.addPlanned(listOf(p.copy(id = UUID.randomUUID().toString(), epochDay = p.epochDay + 7, doneActId = null))) }) { Text("Duplicar +7 d", color = C.Blue) }
                    TextButton({ Store.deletePlanned(p.id) }) { Text("Eliminar", color = C.Red) } } } }
        Text("Se marcan como completadas al vincular una carrera guardada; nunca automáticamente.", color = C.TextDim, fontSize = 12.sp)
    }
}

@Composable fun NewPlannedScreen(back: () -> Unit) {
    var name by remember { mutableStateOf("Rodaje suave") }; var min by remember { mutableStateOf("30") }; var kind by remember { mutableStateOf("Carrera") }; var off by remember { mutableStateOf(1) }
    val base = LocalDate.now()
    Screen("Nueva sesión") {
        Chips(listOf("Carrera", "Descanso"), kind) { kind = it }
        if (kind == "Carrera") { Field("Nombre", name) { name = it }; Field("Objetivo (min)", min, true) { min = it } }
        Text("Día", color = C.TextDim)
        Chips((0..6).map { "${DAYS[base.plusDays(it.toLong()).dayOfWeek.value - 1]} ${base.plusDays(it.toLong()).dayOfMonth}" }, "${DAYS[base.plusDays(off.toLong()).dayOfWeek.value - 1]} ${base.plusDays(off.toLong()).dayOfMonth}") { s ->
            off = (0..6).first { "${DAYS[base.plusDays(it.toLong()).dayOfWeek.value - 1]} ${base.plusDays(it.toLong()).dayOfMonth}" == s } }
        Pill("Guardar", C.Green) { Store.addPlanned(listOf(Planned(UUID.randomUUID().toString(), if (kind == "Descanso") "Descanso" else name, base.plusDays(off.toLong()).toEpochDay(), kind,
            min.toIntOrNull() ?: 30, "Suave", kind == "Descanso", null))); back() }
    }
}

@Composable fun PlanScreen(back: () -> Unit, toForm: () -> Unit) {
    val p by Store.profile.collectAsStateWithLifecycle(); val tm = LocalDate.now().plusDays(1)
    val res = p?.let { Rules.recommend(it, tm.toEpochDay(), tm.dayOfWeek.value) }
    val sess = remember(res) { mutableStateListOf<Rules.Tpl>().apply { res?.let { addAll(it.sessions) } } }
    Screen("Tu punto de partida") {
        if (res == null) { InfoCard("Falta el formulario", ""); Pill("Rellenar", C.Blue) { toForm() } } else {
            InfoCard("Nivel orientativo: ${res.level.label}", res.why + "\nEs editable y no una evaluación médica.")
            res.notes.forEach { Text("• $it", color = C.TextDim, fontSize = 13.sp) }
            sess.forEachIndexed { i, s -> InfoCard("${s.name} · ${s.minutes} min · ${LocalDate.ofEpochDay(s.epochDay)}", "Intensidad: ${s.intensity}\n${s.detail}\nBasado en: ${s.used}")
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    TextButton({ sess[i] = s.copy(minutes = (s.minutes * 3 / 4).coerceAtLeast(15)) }) { Text("Reducir 25 %", color = C.Blue) }
                    TextButton({ sess[i] = s.copy(epochDay = s.epochDay + 1) }) { Text("Posponer 1 día", color = C.Blue) }
                    TextButton({ sess.removeAt(i) }) { Text("Quitar", color = C.Red) } } }
            Text("Procedencia: plantillas propias de thinktwice, pendientes de revisión por una persona entrenadora cualificada.", color = C.TextDim, fontSize = 12.sp)
            Pill("Guardar como rutina", C.Green, enabled = sess.isNotEmpty()) { Store.addPlanned(sess.map { Planned(UUID.randomUUID().toString(), it.name, it.epochDay, it.type, it.minutes, it.intensity, false, null) }); back() }
            Pill("Editar mis respuestas", C.Control, textColor = C.Text) { toForm() } }
    }
}

@Composable fun OnboardingScreen(done: () -> Unit) {
    var p by remember { mutableStateOf(Store.profile.value ?: Profile()) }; var step by remember { mutableStateOf(0) }
    fun u(n: Profile) { p = n }
    Screen("Paso ${step + 1} de 4") {
        when (step) {
            0 -> { Text("¿Qué buscas?", color = C.Text); Chips(listOf("Empezar a correr", "Ganar constancia", "Aumentar distancia", "Preparar una distancia"), p.goal) { u(p.copy(goal = it)) }
                Text("¿Corres actualmente?", color = C.Text); Chips(listOf("Sí", "No"), p.runsNow) { u(p.copy(runsNow = it)) }
                if (p.runsNow == "Sí") { Text("Días por semana", color = C.Text); Chips((1..7).map { "$it" }, "${p.runsPerWeek}") { u(p.copy(runsPerWeek = it.toInt())) } } }
            1 -> { Text("¿Cuánto puedes correr seguido con comodidad?", color = C.Text)
                Chips(listOf("Menos de 5 min", "5–10 min", "10–20 min", "Más de 20 min", "No lo sé"), when (p.comfortMin) { -1 -> "No lo sé"; 0 -> "Menos de 5 min"; 5 -> "5–10 min"; 10 -> "10–20 min"; else -> "Más de 20 min" }) {
                    u(p.copy(comfortMin = when (it) { "Menos de 5 min" -> 0; "5–10 min" -> 5; "10–20 min" -> 10; "Más de 20 min" -> 20; else -> -1 })) }
                Text("Distancia habitual", color = C.Text); Chips(listOf("Menos de 3 km", "3–5 km", "5–10 km", "Más de 10 km", "No lo sé"), p.usualKm) { u(p.copy(usualKm = it)) }
                Text("Tiempo por sesión", color = C.Text); Chips(listOf("20", "30", "45", "60"), "${p.sessionMin}") { u(p.copy(sessionMin = it.toInt())) } }
            2 -> { Text("Días a entrenar", color = C.Text); Chips((1..6).map { "$it" }, "${p.daysWanted}") { u(p.copy(daysWanted = it.toInt())) }
                Text("Días disponibles (toca para marcar)", color = C.Text)
                Chips(DAYS.mapIndexed { i, d -> if ((i + 1) in p.days) "✓ $d" else d }, "") { s -> val i = DAYS.indexOf(s.removePrefix("✓ ")) + 1; u(p.copy(days = if (i in p.days) p.days - i else p.days + i)) }
                Text("Correr", color = C.Text); Chips(listOf("Solo", "En grupo", "Ambas"), p.mode) { u(p.copy(mode = it)) }
                Text("Entorno", color = C.Text); Chips(listOf("Parques", "Ciudad", "Paseo marítimo", "Caminos"), p.terrain) { u(p.copy(terrain = it)) }
                Chips(listOf("Llano", "Acepto desnivel"), p.flat) { u(p.copy(flat = it)) }; Chips(listOf("Circular", "Ida y vuelta"), p.shape) { u(p.copy(shape = it)) } }
            else -> { Field("Municipio", p.town) { u(p.copy(town = it)) }; Field("Provincia", p.province) { u(p.copy(province = it)) }
                Text("El municipio solo sirve para buscar rutas, no para calcular tu nivel.", color = C.TextDim, fontSize = 12.sp)
                Field("Limitación a tener en cuenta (opcional, sin diagnósticos)", p.limitation) { u(p.copy(limitation = it)) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (step > 0) Box(Modifier.weight(1f)) { Pill("Atrás", C.Control, textColor = C.Text) { step-- } }
            Box(Modifier.weight(1f)) { Pill(if (step < 3) "Siguiente" else "Terminar", C.Blue) { if (step < 3) step++ else { Store.saveProfile(p); done() } } } }
    }
}

@Composable fun RoutesScreen(toForm: () -> Unit) {
    val p by Store.profile.collectAsStateWithLifecycle(); val tm = LocalDate.now().plusDays(1)
    val rec = p?.let { Rules.recommend(it, tm.toEpochDay(), tm.dayOfWeek.value) }
    Screen("Rutas") {
        InfoCard(if (p?.town.isNullOrBlank()) "Elige tu municipio" else "${p!!.town}${if (p!!.province.isNotBlank()) " (${p!!.province})" else ""}", "La ubicación actual es opcional; aquí se usa el municipio que indiques.")
        Pill("Cambiar municipio / formulario", C.Control, textColor = C.Text) { toForm() }
        InfoCard("Todavía no tenemos recorridos verificados para esta zona", "El catálogo está vacío: no se muestran rutas inventadas. Hace falta cargar una fuente verificada (ver README).")
        if (rec != null) { Text("Sesión recomendada por duración", style = Title.copy(fontSize = 22.sp))
            rec.sessions.firstOrNull()?.let { InfoCard("${it.name} · ${it.minutes} min", "${it.intensity}\nBasado en: ${it.used}") } }
        else InfoCard("Sin formulario", "Rellénalo para recibir una sesión por duración.")
    }
}

@Composable fun ClubScreen(nav: (Nav) -> Unit) {
    val ms by Store.meetups.collectAsStateWithLifecycle(); var code by remember { mutableStateOf("") }; var msg by remember { mutableStateOf<String?>(null) }
    Screen("Club") {
        InfoCard("Sincronización no configurada", "Las invitaciones, inscripciones y avisos necesitan un servicio con cuenta que aún no está conectado. Lo que crees aquí queda solo en este dispositivo y NO se envía a nadie.")
        Pill("Crear salida", C.Blue) { nav(Nav.NewMeet) }
        Field("Código de invitación", code) { code = it }
        Pill("Unirme con código", C.Control, textColor = C.Text, enabled = code.isNotBlank()) { msg = "No se puede comprobar el código sin el servicio de sincronización." }
        msg?.let { Text(it, color = C.Red, fontSize = 13.sp) }
        if (ms.isEmpty()) InfoCard("Sin encuentros", "Aquí aparecerán tus salidas.")
        ms.forEach { InfoCard("${it.name} · ${it.town}", "${it.whenText} · ${it.distance}\n${it.notes}\nSolo en este dispositivo · sin sincronizar") }
    }
}

@Composable fun NewMeetScreen(back: () -> Unit) {
    var n by remember { mutableStateOf("") }; var t by remember { mutableStateOf("") }; var w by remember { mutableStateOf("") }; var d by remember { mutableStateOf("") }; var x by remember { mutableStateOf("") }
    Screen("Crear salida") {
        Text("Organizar un encuentro deportivo no implica permisos, seguros ni competición oficial.", color = C.TextDim, fontSize = 13.sp)
        Field("Nombre", n) { n = it }; Field("Ciudad", t) { t = it }; Field("Fecha y hora", w) { w = it }; Field("Distancia o duración", d) { d = it }; Field("Instrucciones", x) { x = it }
        Pill("Guardar borrador local", C.Green, enabled = n.isNotBlank()) { Store.addMeetup(Meetup(UUID.randomUUID().toString(), n, t, w, d, x)); back() }
    }
}

@Composable fun ProfileScreen(nav: (Nav) -> Unit) {
    val ctx = LocalContext.current; var askDel by remember { mutableStateOf(false) }
    Screen("Perfil y ajustes") {
        Pill("Editar formulario inicial", C.Blue) { nav(Nav.Onb) }
        Pill("Exportar mis datos (JSON)", C.Control, textColor = C.Text) { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_TEXT, Store.exportAllJson()), "Exportar")) }
        Pill("Eliminar todos mis datos", C.Control, textColor = C.Red) { askDel = true }
        InfoCard("Cuenta", "No hay cuenta. Solo será necesaria para las funciones compartidas, cuando se conecte el servicio.")
        InfoCard("Privacidad", "Tus actividades son privadas y viven solo en este dispositivo. Sin publicidad ni seguimiento.")
        Text("Pendiente: unidades, notificaciones y permisos desde esta pantalla.", color = C.TextDim, fontSize = 12.sp)
    }
    if (askDel) Confirm("¿Eliminar todos los datos?", "Se borran actividades, rutinas y perfil de este dispositivo.", "Eliminar", { Store.deleteAll(); askDel = false }, { askDel = false })
}
