package com.thinktwice.fuckrun.tracking
/** Parciales por km sobre tiempo activo. Solo puntos con precisión válida, sin cruzar segmentos ni huecos > 30 s. Devuelve ms por km completo. */
object Splits {
    fun perKm(raw: List<TrackPoint>): List<Long> {
        val pts = raw.filter { it.accuracyM <= MetricsCalculator.MAX_ACCURACY_M }.sortedBy { it.timeMs }
        val out = mutableListOf<Long>(); var cum = 0.0; var activeMs = 0L; var lastSplitActive = 0L; var next = 1000.0
        for (i in 1 until pts.size) {
            val a = pts[i - 1]; val b = pts[i]
            if (a.segment != b.segment || b.timeMs - a.timeMs > MetricsCalculator.GAP_MS) continue
            val dt = b.timeMs - a.timeMs; val d = MetricsCalculator.haversineM(a, b)
            if (d / (dt / 1000.0) > MetricsCalculator.MAX_SPEED_MS) continue
            cum += d; activeMs += dt
            while (cum >= next) { out += activeMs - lastSplitActive; lastSplitActive = activeMs; next += 1000.0 }
        }
        return out
    }
}
