package com.thinktwice.fuckrun.ui
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

object C {
    val Bg = Color(0xFF0B0C0F); val Surface2 = Color(0xFF15171C); val Card = Color(0xFF1E2128); val Control = Color(0xFF292D35)
    val Text = Color(0xFFF7F8FA); val TextDim = Color(0xFF9DA3AE)
    val Blue = Color(0xFF6C8CFF); val Green = Color(0xFF65D6A0); val Red = Color(0xFFF26B78)
}
// TODO: añadir Inter en res/font y sustituir FontFamily.Default (ver README).
val Inter = FontFamily.Default
/** -85 = -0.085em (no píxeles). */
val Title = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.085).em, color = C.Text)
val BigNumber = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 56.sp, letterSpacing = (-0.085).em,
    fontFeatureSettings = "tnum", color = C.Text)

@Composable fun FuckrunTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(background = C.Bg, surface = C.Surface2, onBackground = C.Text, onSurface = C.Text, primary = C.Blue),
    content = content)
