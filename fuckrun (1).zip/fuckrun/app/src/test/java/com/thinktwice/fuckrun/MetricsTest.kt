package com.thinktwice.fuckrun
import com.thinktwice.fuckrun.tracking.*
import org.junit.Assert.*
import org.junit.Test

class MetricsTest {
    // ~3 m/s hacia el este en el ecuador: 1 grado lon ≈ 111195 m
    private fun line(seconds: Int, seg: Int = 0, t0: Long = 0, lon0: Double = 0.0) =
        (0..seconds).map { TrackPoint(t0 + it * 1000L, 0.0, lon0 + 3.0 * it / 111195.0, 5f, seg) }

    @Test fun distanceAndAvgSpeed() {
        val m = MetricsCalculator.compute(line(60), 0, 60_000)
        assertEquals(180.0, m.distanceM, 2.0); assertEquals(10.8, m.avgSpeedKmh!!, 0.3)
    }
    @Test fun gpsJumpIsDiscarded() {
        val p = line(60).toMutableList(); p[30] = p[30].copy(lat = 0.01)
        assertEquals(180.0, MetricsCalculator.compute(p, 0, 60_000).distanceM, 3.0)
    }
    @Test fun poorAccuracyIsDiscarded() {
        val p = line(60).map { it.copy(accuracyM = 80f) }
        assertEquals(0.0, MetricsCalculator.compute(p, 0, 60_000).distanceM, 0.0)
    }
    @Test fun pauseExcludedFromActiveTime() {
        val p = line(30) + line(30, seg = 1, t0 = 90_000, lon0 = 0.01)
        val m = MetricsCalculator.compute(p, 0, 120_000)
        assertEquals(60_000, m.activeMs); assertEquals(120_000, m.elapsedMs)
    }
    @Test fun noDataGivesNullNotInvented() {
        val m = MetricsCalculator.compute(line(2), 0, 2_000)
        assertNull(m.maxSpeedKmh); assertNull(m.minMovingSpeedKmh)
    }
    @Test fun aggregatePaceUsesTotals() {
        val a = SessionMetrics(1000.0, 0, 300_000, null, null, null, null, 0)
        val b = SessionMetrics(10000.0, 0, 3_600_000, null, null, null, null, 0)
        assertEquals(354.5, MetricsCalculator.aggregatePaceSecPerKm(listOf(a, b))!!, 0.1)
    }
}
