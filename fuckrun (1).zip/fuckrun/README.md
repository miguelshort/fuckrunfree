# fuckrun v0.2
Abrir en Android Studio (JDK 17), sincronizar (genera el wrapper) y ejecutar `app`. Tests: `./gradlew :app:testDebugUnitTest`.
**Nada de esto se ha compilado ni probado en dispositivo** (el entorno de escritura no tiene Android SDK). Esperad errores de compilación menores.

## Implementado (sin configuración, solo local)
Registro GPS en primer plano con pausa/reanudación, bloqueo de controles, confirmación al terminar, guardar/descartar con confirmación,
recuperación tras cierre (diario incremental), historial, progreso semanal/mensual/anual (azul #6C8CFF, ritmo agregado correcto),
actividad manual diferenciada, parciales por km, nota privada, exportación GPX (con aviso) y JSON, formulario por pasos,
reglas explícitas de nivel y sesiones (con procedencia y opciones reducir/posponer/quitar), rutinas con gráfico circular,
vinculación manual carrera-sesión, Rutas con estado "sin recorridos verificados" y sesión por duración, Club local, borrado de datos.

## Pendiente / requiere configuración
- Fuente Inter (añadir a res/font). Desenfoque real de barra, paneles y difuminación superior (Haze/RenderEffect).
- Mapas con proveedor (clave, costes, atribución) y catálogo de rutas verificado con fuente y fecha. Hoy el trazado se dibuja sin mapa base.
- Buscador de municipios/provincias (hoy texto libre) y filtros de rutas.
- Backend con autenticación para invitaciones, plazas, avisos y control de acceso: NO existe; el Club solo guarda borradores locales.
- Pérdida de permiso/GPS apagado/batería baja/reinicio: gestión parcial (el diario se conserva), sin avisos dedicados.
- Calendario mensual visual, recordatorios, ajustes de unidades/notificaciones, minimizar sesión, movimiento reducido, Room/cifrado.
- Recomendaciones: plantillas sin revisión de una persona entrenadora cualificada.
